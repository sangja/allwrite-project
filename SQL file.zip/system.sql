create user allwrite identified by "1234";
GRANT ALL PRIVILEGES TO allwrite;